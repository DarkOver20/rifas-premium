<?php
require_once __DIR__ . '/admin/includes/config.php';
require_once __DIR__ . '/admin/includes/functions.php';

if (strpos($_SERVER['REQUEST_URI'], '/admin/includes/functions.php') !== false) {
    require __DIR__ . '/admin/includes/functions.php';
    exit;
}

$request = isset($_GET['url']) ? strtolower(trim($_GET['url'], '/')) : '';


switch ($request) {
    case '':
      
        require __DIR__ . '/landing.php';
        break;
        
    case 'sys-396/access':
      
        if (is_logged_in()) {
            redirect('/dashboard');
        }
        require __DIR__ . '/admin/usuario/login.php';
        break;
        
    case 'dashboard':
        
        require_admin();
        require __DIR__ . '/admin/dashboard.php';
        break;
    
    case 'eventos':
        
        require_admin();
        require __DIR__ . '/admin/eventosact.php';
        break;
    
    case 'eventos/crear':
        
        require_admin();
        require __DIR__ . '/admin/eventos/nuevo.php';
        break;

    case 'metodos':
    
        require_admin();
        require __DIR__ . '/admin/metodos_pago/index.php';
        break;


    case 'metodos/tasas':
            require_admin();
            require __DIR__ . '/admin/metodos_pago/tasas.php';
            break; 

    case 'logout':
        
        require __DIR__ . '/logout.php';
        break;
        
    default:
        
        if (preg_match('/^evento\/(\d+)\/[a-z0-9-]+$/i', $request, $matches)) {
            
            $_GET['id'] = (int)$matches[1];
            require __DIR__ . '/evento2.php';
        }
            
        elseif (preg_match('/^admin\/solicitud\/comprobante-([a-z0-9-]+)$/i', $request, $matches)) {
            
            require_admin();
            $nombre_archivo = $matches[1];
            $ruta_comprobante = dirname(__DIR__) . '/comprobante_' . $nombre_archivo;
            
            if (file_exists($ruta_comprobante)) {
                $mime_type = mime_content_type($ruta_comprobante);
                header('Content-Type: ' . $mime_type);
                readfile($ruta_comprobante);
                exit;
            } else {
                header("HTTP/1.0 404 Not Found");
                echo "Comprobante no encontrado";
                exit;
            }}
        elseif (preg_match('/^admin\/solicitud\/(\d+)\/\d+$/i', $request, $matches)) {
            
            require_admin();
            $_GET['id'] = (int)$matches[1];
            require __DIR__ . '/admin/solicitudes/detalle2.php';
        }
        
        else {
            
            header("HTTP/1.0 404 Not Found");
            require __DIR__ . '/404.php';
        }

        
}

?>