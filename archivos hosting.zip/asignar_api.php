<?php
require_once __DIR__ . '/admin/includes/config.php';
require_once __DIR__ . '/admin/includes/functions.php';

header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'asignar_ganador':
                $evento_id = intval($_POST['evento_id']);
                $numero_boleto = sanitize($_POST['numero_boleto']);
                
                $stmt = $pdo->prepare("SELECT b.*, t.nombre, t.cedula, t.telefono
                                      FROM boletos b
                                      LEFT JOIN transacciones t ON b.transaccion_id = t.id
                                      WHERE b.evento_id = ? AND b.numero_boleto = ?");
                $stmt->execute([$evento_id, $numero_boleto]);
                $boleto = $stmt->fetch();
                
                if ($boleto) {
                    $stmt = $pdo->prepare("UPDATE eventos SET boleto_ganador = ? WHERE id = ?");
                    $stmt->execute([$numero_boleto, $evento_id]);
                    
                    echo json_encode([
                        'success' => true,
                        'message' => 'Boleto ganador asignado correctamente',
                        'comprador' => [
                            'nombre' => $boleto['nombre'],
                            'cedula' => $boleto['cedula'],
                            'telefono' => $boleto['telefono'],
                        ]
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'El boleto no existe'
                    ]);
                }
                break;
                
            default:
                echo json_encode(['success' => false, 'message' => 'Acción no válida']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error en la base de datos']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error del servidor']);
}