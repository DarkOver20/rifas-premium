<?php

require_once __DIR__ . '/../admin/includes/config.php';
require_once __DIR__ . '/../admin/includes/functions.php';

function sendResponse($success, $message, $data = [], $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendResponse(false, 'Método no permitido', [], 405);
    }

    $input = file_get_contents('php://input');
    if (empty($input)) {
        sendResponse(false, 'Datos no proporcionados', [], 400);
    }

    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        sendResponse(false, 'JSON inválido: ' . json_last_error_msg(), [], 400);
    }

    if (empty($data['eventId']) || !is_numeric($data['eventId'])) {
        sendResponse(false, 'ID de evento no válido', [], 400);
    }

    $eventId = (int)$data['eventId'];
    $db = getDBConnection();

    $stmt = $db->prepare("SELECT id, estado, fecha_fin FROM eventos WHERE id = ?");
    $stmt->execute([$eventId]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$evento) {
        sendResponse(false, 'Evento no encontrado', ['eventId' => $eventId], 404);
    }

    if ($evento['estado'] === 'finalizado') {
        sendResponse(true, 'El evento ya estaba finalizado', [
            'eventId' => $eventId,
            'fecha_fin' => $evento['fecha_fin']
        ]);
    }

    $fechaFin = new DateTime($evento['fecha_fin']);
    $now = new DateTime();

    if ($fechaFin > $now) {
        sendResponse(false, 'El evento aún no ha finalizado', [
            'eventId' => $eventId,
            'fecha_fin' => $evento['fecha_fin'],
            'current_time' => $now->format('Y-m-d H:i:s')
        ], 400);
    }

    $stmt = $db->prepare("UPDATE eventos SET estado = 'finalizado', updated_at = NOW() WHERE id = ?");
    $stmt->execute([$eventId]);
    $affectedRows = $stmt->rowCount();

    if ($affectedRows > 0) {
        sendResponse(true, 'Evento actualizado a finalizado', [
            'eventId' => $eventId,
            'previous_status' => $evento['estado'],
            'fecha_fin' => $evento['fecha_fin']
        ]);
    } else {
        sendResponse(false, 'No se pudo actualizar el evento', [
            'eventId' => $eventId,
            'affected_rows' => $affectedRows
        ], 500);
    }

} catch (PDOException $e) {
    error_log('Error de base de datos: ' . $e->getMessage());
    sendResponse(false, 'Error de base de datos', [
        'error_code' => $e->getCode(),
        'error_message' => $e->getMessage()
    ], 500);

} catch (Exception $e) {
    error_log('Error general: ' . $e->getMessage());
    sendResponse(false, 'Error en el servidor', [
        'error_code' => $e->getCode(),
        'error_message' => $e->getMessage()
    ], 500);
}