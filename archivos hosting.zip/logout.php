<?php
require_once './admin/includes/config.php';


$_SESSION = [];

session_destroy();

header('Location: /sys-396/access');
exit;